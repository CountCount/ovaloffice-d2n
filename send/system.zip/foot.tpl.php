<?php

?>
	</div>
	<script type="text/javascript">
				// Tabs
				$('#tabs').tabs();
				// Accordion
				$("#accordion").accordion({ header: "h3", autoHeight: 'false' });
	</script>
</body>
</html>

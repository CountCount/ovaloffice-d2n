<?php ?>
<div class="news"><strong>News</strong>
				<p><span class="date">06/20/2011, 12:30 pm</span><br/>Officially pimped (added to ingame's site directory)</p>
				<p><span class="date">05/25/2011, 2:00 pm</span><br/>Official test mode started</p>
				<p><span class="date">05/13/2011, 1:00 pm</span><br/>Black Friday: First translation of Oval Office set up</p>
				</div>
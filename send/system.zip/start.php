<?php
#include_once 'cfg.php';
?>
<p>To access the Oval Office you have to identify yourself. Please use the in-game site directory (book icon in the top left corner of the D2N site).</p>
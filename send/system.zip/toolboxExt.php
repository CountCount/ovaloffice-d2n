<?php
print 'Extended Toolbox is no longer available. Please update the <a href="http://d2n.sindevel.com/oo/js/ext/oo_toolbox.user.js">standard toolbox</a> to get rid of the hover modus.';
exit;
